


#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <algorithm>
using namespace std;

int N;
vector<vector<int>> maze;

// 1 = wall, 0 = path, 2 = solution

// Random Maze Generator
void generateMaze(int r, int c) {
    maze[r][c] = 0;

    int dr[] = {-2, 2, 0, 0};
    int dc[] = {0, 0, -2, 2};
    int order[] = {0, 1, 2, 3};

    // Randomize direction order
    for (int i = 3; i > 0; i--) {
        int j = rand() % (i + 1);
        swap(order[i], order[j]);
    }

    // Carve corridors, leaving walls between them
    for (int i = 0; i < 4; i++) {
        int d = order[i];
        int nr = r + dr[d];
        int nc = c + dc[d];

        if (nr > 0 && nr < N - 1 &&
            nc > 0 && nc < N - 1 &&
            maze[nr][nc] == 1) {

            maze[r + dr[d] / 2][c + dc[d] / 2] = 0;
            generateMaze(nr, nc);
        }
    }
}

// Maze Solver using DFS
bool solveMaze(int r, int c) {
    if (r < 0 || r >= N || c < 0 || c >= N)
        return false;

    if (maze[r][c] == 1 || maze[r][c] == 2)
        return false;

    if (r == N - 2 && c == N - 2)
        return true;

    int original = maze[r][c];
    maze[r][c] = 2;

    int dr[] = {1, 0, -1, 0};
    int dc[] = {0, 1, 0, -1};

    for (int i = 0; i < 4; i++) {
        if (solveMaze(r + dr[i], c + dc[i]))
            return true;
    }

    maze[r][c] = original;
    return false;
}

// Display maze
void displayMaze() {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            if (i == 1 && j == 1)
                cout << "S ";
            else if (i == N - 2 && j == N - 2)
                cout << "E ";
            else if (maze[i][j] == 1)
                cout << "# ";
            else if (maze[i][j] == 2)
                cout << "* ";
            else
                cout << ". ";
        }
        cout << '\n';
    }
}

int main() {
    srand(static_cast<unsigned int>(time(0)));

    cout << "Enter maze size (5 to 100): ";
    cin >> N;

    if (N < 5 || N > 100) {
        cout << "Enter a size between 5 and 100.\n";
        return 0;
    }

    // Use an odd internal grid so corridor carving works.
    // The requested size can be even or odd.
    int requestedSize = N;
    if (N % 2 == 0)
        N--;

    maze.assign(N, vector<int>(N, 1));

    generateMaze(1, 1);

    // Open a connection to the exit
    maze[N - 2][N - 1] = 0;

    cout << "\nGenerated Maze:\n";
    displayMaze();

    if (solveMaze(1, 1)) {
        cout << "\nSolved Maze (* = solution path):\n";
        displayMaze();
    } else {
        cout << "\nNo solution found.\n";
    }

    return 0;
}



